package chatting_application;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class Server implements ActionListener {

    private JTextField text;
    private JPanel a1;
    private static Box vertical = Box.createVerticalBox();
    private static JFrame f = new JFrame();
    private static Map<Socket, DataOutputStream> clients = new HashMap<>();
    
    private ImageIcon profileIcon = new ImageIcon("path_to_default_profile_image.jpg");
    private JLabel profileLabel = new JLabel(profileIcon);

    Server() {
        f.setLayout(null);

        JPanel p1 = new JPanel();
        p1.setBackground(new Color(7, 94, 84));
        p1.setBounds(0, 0, 450, 70);
        f.add(p1);
        p1.setLayout(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("arrow.jpg"));
        Image i2 = i1.getImage().getScaledInstance(25, 25, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel back = new JLabel(i3);
        back.setBounds(5, 20, 25, 25);
        p1.add(back);

        back.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent ae) {
                f.setVisible(false);
            }
        });

        ImageIcon i4 = new ImageIcon(ClassLoader.getSystemResource("video.png"));
        Image i5 = i4.getImage().getScaledInstance(30, 30, Image.SCALE_DEFAULT);
        ImageIcon i6 = new ImageIcon(i5);
        JLabel video = new JLabel(i6);
        video.setBounds(300, 20, 35, 30);
        p1.add(video);

        ImageIcon i7 = new ImageIcon(ClassLoader.getSystemResource("phone.png"));
        Image i8 = i7.getImage().getScaledInstance(35, 30, Image.SCALE_DEFAULT);
        ImageIcon i9 = new ImageIcon(i8);
        JLabel phone = new JLabel(i9);
        phone.setBounds(360, 20, 35, 30);
        p1.add(phone);

        ImageIcon i10 = new ImageIcon(ClassLoader.getSystemResource("3icon.png"));
        Image i11 = i10.getImage().getScaledInstance(10, 25, Image.SCALE_DEFAULT);
        ImageIcon i12 = new ImageIcon(i11);
        JLabel morevert = new JLabel(i12);
        morevert.setBounds(420, 20, 10, 25);
        p1.add(morevert);

        profileLabel.setBounds(320, 10, 40, 40);
        p1.add(profileLabel);

        a1 = new JPanel();
        a1.setBounds(5, 75, 425, 570);
        a1.setLayout(new BorderLayout());
        f.add(a1);

        text = new JTextField();
        text.setBounds(5, 655, 310, 40);
        text.setFont(new Font("SAN_SERIF", Font.PLAIN, 16));
        f.add(text);

        JButton send = new JButton("Send");
        send.setBounds(320, 655, 123, 40);
        send.setBackground(new Color(7, 94, 84));
        send.addActionListener(this);
        send.setForeground(Color.WHITE);
        send.setFont(new Font("SAN_SERIF", Font.PLAIN, 16));
        f.add(send);

        profileLabel.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));

                int result = fileChooser.showOpenDialog(f);

                if (result == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = fileChooser.getSelectedFile();
                    ImageIcon selectedIcon = new ImageIcon(selectedFile.getAbsolutePath());
                    profileLabel.setIcon(selectedIcon);
                }
            }
        });

        f.setSize(450, 700);

        f.setLocation(200, 50);
        f.setUndecorated(true);
        f.getContentPane().setBackground(Color.WHITE);
        f.setVisible(true);
    }

    public static void main(String args[]) {
        SwingUtilities.invokeLater(() -> new Server());

        try {
            ServerSocket serverSocket = new ServerSocket(1900);
            while (true) {
                Socket clientSocket = serverSocket.accept();
                DataInputStream din = new DataInputStream(clientSocket.getInputStream());
                DataOutputStream dout = new DataOutputStream(clientSocket.getOutputStream());

                clients.put(clientSocket, dout);

                while (true) {
                    String msg = din.readUTF();
                    if (msg.equals("exit")) {
                        break;
                    }
                    JPanel panel = formatLabel(msg, null);
                    JPanel left = new JPanel(new BorderLayout());
                    left.add(panel, BorderLayout.LINE_START);
                    vertical.add(left);

                    SwingUtilities.invokeLater(() -> f.validate());
                }

                clients.remove(clientSocket);
                clientSocket.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            String out = text.getText();

            JPanel p2 = formatLabel(out, profileIcon);

            JPanel right = new JPanel(new BorderLayout());
            right.add(p2, BorderLayout.LINE_END);

            vertical.add(right);
            vertical.add(Box.createVerticalStrut(15));

            a1.add(vertical, BorderLayout.PAGE_START);

            for (DataOutputStream clientDout : clients.values()) {
                clientDout.writeUTF(out);
            }

            text.setText("");
            SwingUtilities.invokeLater(() -> f.validate());
        } catch (Exception ae) {
            ae.printStackTrace();
        }
    }

    public static JPanel formatLabel(String out, ImageIcon profileIcon) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        if (profileIcon != null) {
            JLabel profileLabel = new JLabel(profileIcon);
            panel.add(profileLabel);
        }

        JLabel output = new JLabel(out);
        output.setFont(new Font("Tahoma", Font.PLAIN, 16));
        output.setBackground(new Color(37, 211, 102));
        output.setOpaque(true);
        output.setBorder(new EmptyBorder(15, 15, 15, 50));

        panel.add(output);

        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");

        JLabel time = new JLabel();
        time.setText(sdf.format(cal.getTime()));
        panel.add(time);

        return panel;
    }
}
